# Memory des Saveurs du Monde 🌍

Jeu Memory multijoueur pour la Semaine du Goût.

## Contenu
- `index.html` : le jeu complet.
- 25 paires = 50 cartes.
- Les joueurs rejoignent avec un code.
- L'animateur voit le classement en direct.
- Chaque joueur joue sur son propre téléphone.
- Le premier à trouver les 25 paires gagne.

## Mise en ligne gratuite avec GitHub Pages
1. Crée un compte GitHub.
2. Crée un nouveau dépôt (repository), par exemple `memory-saveurs`.
3. Ajoute `index.html`.
4. Dans Settings > Pages, choisis le déploiement depuis la branche `main`.
5. GitHub donne une adresse `https://...github.io/...`.
6. Ouvre cette adresse sur l'ordinateur de l'animateur et sur les téléphones.

## Important
L'ordinateur de l'animateur doit garder la page ouverte pendant la partie.
Le jeu utilise PeerJS pour établir les connexions entre navigateurs.
